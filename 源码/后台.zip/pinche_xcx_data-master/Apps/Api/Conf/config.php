<?php
return array(
	//'配置项'=>'配置值'
	'APPID' => 'wx61f7708fbb157848',
	'AppSecret' => '57556a858121fae443f59863f9cb1cdb',
);